"""
Pyserial Test Code
TO use connect arduino with a Serial cable to your computer
install with
pip install pyserial
"""


##import serial                                              # not pyserial 
### on linux open port
##ser = serial.Serial('/dev/ttyUSB0', 9600)             #9600 is Arduino Baudrate

### on Windows open port
##ser = serial.Serial('COM3',9600) 

### write a string to Arduino
##ser.write(b'hello')                                                    #b means bytestring

### read a string from Arduino
##output=ser.read() 

### close port
##ser.close()             

 
